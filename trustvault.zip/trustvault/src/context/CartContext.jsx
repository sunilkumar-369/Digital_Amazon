import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useToast } from './ToastContext.jsx';

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

const read = (key) => {
  try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; }
};
const write = (key, val) => {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* storage may be blocked */ }
};

// Store only what the cart/checkout needs — not the whole product
const snap = (p) => ({
  id: p.id, title: p.title, price: Number(p.price) || 0, imageUrl: p.imageUrl || '',
  category: p.category, sellerId: p.sellerId, sellerName: p.sellerName, sample: !!p.sample,
});

export function CartProvider({ children }) {
  const toast = useToast();
  const [items, setItems] = useState(() => read('tv_cart'));
  const [wish, setWish] = useState(() => read('tv_wish'));

  useEffect(() => write('tv_cart', items), [items]);
  useEffect(() => write('tv_wish', wish), [wish]);

  const inCart = useCallback((id) => items.some((i) => i.id === id), [items]);
  const inWish = useCallback((id) => wish.some((i) => i.id === id), [wish]);

  const add = (p) => {
    if (inCart(p.id)) { toast('Already in your cart'); return; }
    setItems((prev) => [...prev, snap(p)]);
    toast(`Added "${p.title}" to cart`);
  };
  const remove = (id) => setItems((prev) => prev.filter((i) => i.id !== id));
  const clear = () => setItems([]);

  const toggleWish = (p) => {
    if (inWish(p.id)) {
      setWish((prev) => prev.filter((i) => i.id !== p.id));
      toast('Removed from wishlist');
    } else {
      setWish((prev) => [...prev, snap(p)]);
      toast('Saved to wishlist');
    }
  };

  const total = useMemo(() => items.reduce((s, i) => s + i.price, 0), [items]);

  return (
    <CartContext.Provider value={{ items, wish, total, inCart, inWish, add, remove, clear, toggleWish }}>
      {children}
    </CartContext.Provider>
  );
}
