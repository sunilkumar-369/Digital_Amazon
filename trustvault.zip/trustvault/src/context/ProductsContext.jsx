import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot, orderBy, query } from 'firebase/firestore';
import { db, isConfigured } from '../firebase.js';
import { SHOW_SAMPLES, SAMPLE_THRESHOLD } from '../config.js';
import { SAMPLE_PRODUCTS } from '../data/sampleProducts.js';

const ProductsContext = createContext(null);
export const useProducts = () => useContext(ProductsContext);

export function ProductsProvider({ children }) {
  const [real, setReal] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!isConfigured) { setLoading(false); return; }
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snap) => {
        setReal(snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((p) => p.status !== 'archived'));
        setLoading(false);
      },
      (err) => { setError(err); setLoading(false); }
    );
  }, []);

  const products = useMemo(
    () => (SHOW_SAMPLES && real.length < SAMPLE_THRESHOLD ? [...real, ...SAMPLE_PRODUCTS] : real),
    [real]
  );

  return (
    <ProductsContext.Provider value={{ products, realCount: real.length, loading, error }}>
      {children}
    </ProductsContext.Provider>
  );
}
