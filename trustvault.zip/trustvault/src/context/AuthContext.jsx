import { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signInWithPopup, signOut, updateProfile, sendPasswordResetEmail,
} from 'firebase/auth';
import { doc, getDoc, onSnapshot, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider, isConfigured } from '../firebase.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null); // { name, email, role }
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isConfigured) { setLoading(false); return; }
    let unsubProfile = () => {};
    const unsubAuth = onAuthStateChanged(auth, (u) => {
      unsubProfile();
      setUser(u);
      if (u) {
        // Live-listen so the profile appears the moment registration writes it
        unsubProfile = onSnapshot(
          doc(db, 'users', u.uid),
          (snap) => setProfile(snap.exists() ? snap.data() : null),
          () => setProfile(null)
        );
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => { unsubAuth(); unsubProfile(); };
  }, []);

  const register = async ({ name, email, password, role }) => {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: name });
    await setDoc(doc(db, 'users', cred.user.uid), {
      name, email, role, createdAt: serverTimestamp(),
    });
    return cred.user;
  };

  const login = (email, password) => signInWithEmailAndPassword(auth, email, password);

  // For first-time Google users, `role` decides what account type is created
  const loginWithGoogle = async (role = 'buyer') => {
    const cred = await signInWithPopup(auth, googleProvider);
    const ref = doc(db, 'users', cred.user.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        name: cred.user.displayName || 'User',
        email: cred.user.email || '',
        role,
        createdAt: serverTimestamp(),
      });
    }
    return cred.user;
  };

  const resetPassword = (email) => sendPasswordResetEmail(auth, email);
  const logout = () => signOut(auth);

  const becomeSeller = async () => {
    if (!user) return;
    await updateDoc(doc(db, 'users', user.uid), { role: 'seller' });
  };

  const value = {
    user, profile, loading,
    isSeller: profile?.role === 'seller',
    register, login, loginWithGoogle, resetPassword, logout, becomeSeller,
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
