# TrustVault — Digital Product Marketplace

Sellers list digital products, buyers purchase them and download from their library.
Built with **React + Vite + Tailwind + Firebase (Auth & Firestore)**, deployed on **Vercel**.

## What's included

- Home (hero search, categories, trending, how it works, seller CTA)
- Browse with search, category filter and sorting
- Product page, wishlist, cart, "My library" with private downloads
- Email + Google sign-up as **buyer** or **seller** (buyers can upgrade to seller later)
- Seller dashboard: revenue, sales, transactions, add / edit / hide products
- Navbar icons: wishlist, cart, account menu

> **Important — payments:** checkout is a **demo** (no money is charged). See "Adding real payments" at the bottom.

---

## 1. Set up Firebase (free)

1. Go to https://console.firebase.google.com → **Add project** (name it e.g. `trustvault`).
2. **Authentication → Get started → Sign-in method**: enable **Email/Password** and **Google**.
3. **Firestore Database → Create database** → choose a location → start in **production mode**.
4. Firestore → **Rules** tab → paste the contents of `firestore.rules` → **Publish**.
5. **Project settings (gear) → Your apps → Web (`</>`)** → register an app → copy the `firebaseConfig` values.

## 2. Run it on your computer

```bash
npm install
cp .env.example .env.local      # then paste your Firebase values into .env.local
npm run dev                     # opens http://localhost:5173
```

Map the Firebase config to `.env.local`:

| Firebase field      | Variable                              |
| ------------------- | ------------------------------------- |
| apiKey              | VITE_FIREBASE_API_KEY                 |
| authDomain          | VITE_FIREBASE_AUTH_DOMAIN             |
| projectId           | VITE_FIREBASE_PROJECT_ID              |
| storageBucket       | VITE_FIREBASE_STORAGE_BUCKET          |
| messagingSenderId   | VITE_FIREBASE_MESSAGING_SENDER_ID     |
| appId               | VITE_FIREBASE_APP_ID                  |

## 3. Put the code on GitHub

1. Create a free account at https://github.com, then **New repository** → name `trustvault` → Create (leave it empty).
2. In the project folder:

```bash
git init
git add .
git commit -m "TrustVault marketplace"
git branch -M main
git remote add origin https://github.com/<your-username>/trustvault.git
git push -u origin main
```

(No Git installed? On the repo page choose **Add file → Upload files** and drag in the project files — but not `node_modules`. `.env.local` must never be uploaded.)

## 4. Deploy on Vercel (free)

1. Go to https://vercel.com → **Sign up with GitHub**.
2. **Add New → Project → Import** your `trustvault` repo.
3. Vercel auto-detects **Vite** (build `npm run build`, output `dist`). Don't change it.
4. Open **Environment Variables** and add all six `VITE_FIREBASE_*` values (and optionally `VITE_CURRENCY`, `VITE_SHOW_SAMPLES`).
5. Click **Deploy**. In ~1 minute you get a live link like `trustvault.vercel.app`.

Every `git push` to `main` redeploys automatically.

## 5. Final step (required for login to work live)

Firebase Console → **Authentication → Settings → Authorized domains → Add domain** → add your Vercel domain (e.g. `trustvault.vercel.app`). Without this, Google sign-in shows an "unauthorized domain" error.

Changed an environment variable on Vercel? Redeploy for it to take effect.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| Yellow "Firebase isn't connected" banner | Env vars missing — add them (locally in `.env.local`, on Vercel in Settings → Environment Variables) and redeploy |
| Blank page when refreshing a sub-page | `vercel.json` handles this; make sure it's in the repo |
| "permission-denied" | Publish `firestore.rules` in Firebase |
| Google login: unauthorized domain | Step 5 above |
| Can't register | Enable Email/Password in Firebase Authentication |

## How selling works

- Sellers paste a **cover image link** and a **private download link** (Google Drive, Dropbox, Mega…).
- The download link is stored in a separate Firestore document (`productFiles`) that only the seller and buyers who purchased can read.
- Buyers see purchases under **My library**.
- To remove the sample products, set `VITE_SHOW_SAMPLES=false` on Vercel and redeploy (they also disappear automatically once 8 real products exist).

## Adding real payments (next step)

Right now the browser writes the purchase record itself, so anyone could "buy" for free by tampering with requests. Before charging real customers:

1. Pick a provider — **Razorpay** (India) or **Stripe**.
2. Add a Vercel serverless function (`/api/create-order`) that creates the payment session using your secret key (kept in Vercel env vars, never in the frontend).
3. Add a webhook function (`/api/webhook`) that verifies the payment signature and, using the **Firebase Admin SDK**, writes the `purchases` and `sales` documents.
4. In `firestore.rules`, change the two rules marked "demo checkout" to `allow create: if false;`.

Also consider: Firebase Storage for direct file uploads (needs the Blaze pay-as-you-go plan), seller payouts, refunds and a terms/privacy page before launch.
