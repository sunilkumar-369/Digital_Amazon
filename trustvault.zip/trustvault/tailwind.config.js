/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: '#1D3557', 700: '#16294a', 900: '#0f1d36' },
        accent: { DEFAULT: '#FB8500', dark: '#e07700' },
        teal: { DEFAULT: '#2A9D8F' },
        gold: { DEFAULT: '#FFB703' },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
